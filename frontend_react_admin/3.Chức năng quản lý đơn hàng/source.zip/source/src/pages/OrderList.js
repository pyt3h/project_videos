import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { BASE_URL } from "config";

export default function OrderList() {
  const [orderList, setOrderList]=  useState([]);
  const [keyword, setKeyword] = useState("");
  const getOrderList = function () {
    let url = BASE_URL + '/api/search-order?keyword=' + keyword;
    //alert(url);
    let options = {
      headers: {
        "Authorization": "Bearer " + localStorage.getItem("token")
      }
    };
    fetch(url, options).then(resp => resp.json()).then(result => {
      //console.log(result);
      setOrderList(result);
    });
  }

  useEffect(function() {
    // init app
    getOrderList();
  }, []);
  return (
    <div className="container mt-3">
      <form className="row">
        <div className="col-9">
          <input className="form-control" placeholder="Tìm kiếm theo tên/sđt khách hàng/tên sản phẩm" />
        </div>
        <div className="col-3">
          <button className="btn btn-primary">Tìm kiếm</button>
        </div>
      </form>
      <table className="table mt-3">
        <thead>
          <tr>
            <th style={{width:"25%"}}>Khách hàng</th>
            <th style={{width:"25%"}}>Sản phẩm</th>
            <th style={{width:"20%"}}>Ngày mua</th>
            <th style={{width:"20%"}}>Trạng thái</th>
            <th style={{width:"10%"}}></th>
          </tr>
        </thead>
        <tbody>
          {orderList.map(order => 
            <tr key={order.id}>
              <td>{order.customer_name} ({order.customer_phone})</td>
              <td>{order.product_name} (Số lượng: {order.qty})</td>
              <td>{order.order_date}</td>
              <td>
                {order.status == 0 && 'Đang chờ giao hàng'}
                {order.status == 1 && 'Đã giao hàng'}
                {order.status == 2 && 'Đã hủy'}
              </td>
              <td>
                <Link className="btn btn-sm btn-secondary" to={"/order-detail/"+order.id}>Xem</Link>
              </td>
            </tr>
          )}
          
        </tbody>
      </table>
      <nav aria-label="Page navigation example">
        <ul className="pagination">
          <li className="page-item"><a className="page-link" href="#/">&laquo;</a></li>
          <li className="page-item"><a className="page-link" href="#/">&lsaquo;</a></li>
          <li className="page-item"><a className="page-link" href="#/">&rsaquo;</a></li>
          <li className="page-item"><a className="page-link" href="#/">&raquo;</a></li>
        </ul>
        <span>Hiển thị 1-10 trên tổng số 25 đơn hàng</span>
      </nav>
    </div>
  );
}