import { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { BASE_URL } from "config";

export default function OrderDetail() {
  const [order, setOrder] = useState({});
  const {id} = useParams();
  const navigate = useNavigate();

  let options = {
    headers: {
      "Authorization": "Bearer " + localStorage.getItem("token")
    }
  };

  const confirmOrder = async function() {
    if(window.confirm('Xác nhận đơn hàng đã được giao?')){
      let url = BASE_URL + '/api/confirm-order/' + id;
      fetch(url, {...options, method: 'POST'}).then(_ => navigate("/"));
    }
  }

  const cancelOrder =  async function() {
    if(window.confirm('Hủy đơn hàng này?')){
      let url = BASE_URL + '/api/cancel-order/' + id;
      fetch(url, {...options, method: 'POST'}).then(_ => navigate("/"));
    }
  }
  useEffect(function() {
    //init app
    let url = BASE_URL + '/api/get-order-by-id/' + id;
    //alert(url);
    
    fetch(url, options).then(resp => resp.json()).then(result => {
      //console.log(result);
      setOrder(result);
    });
  }, []);
  return (
    <div className="container mt-3">
      <h4>Thông tin đơn hàng</h4>
      <hr />
      <table className="table table-form">
        <tbody>
          <tr>
            <th colspan="2">
              <h5>Thông tin khách hàng</h5>
            </th>
          </tr>
          <tr>
            <th style={{width:"30%"}}>Họ và tên:</th>
            <td>{order.customer_name}</td>
          </tr>
          <tr>
            <th>Số điện thoại:</th>
            <td>{order.customer_phone}</td>
          </tr>
          <tr>
            <th>Địa chỉ:</th>
            <td>{order.customer_address}</td>
          </tr>
          <tr>
            <th colspan="2">
              <h5>Thông tin sản phẩm</h5>
            </th>
          </tr>
          <tr>
            <th>Tên sản phẩm:</th>
            <td>{order.product_name}</td>
          </tr>
          <tr>
            <th>Đơn giá:</th>
            <td>{order.price_unit} ₫</td>
          </tr>
          <tr>
            <th>Số lượng:</th>
            <td>
              {order.qty}
            </td>
          </tr>
          <tr>
            <th>
              <h5>Trạng thái đơn hàng:</h5>
            </th>
            <td>
              {order.status == 0 && 'Đang chờ giao hàng'}
              {order.status == 1 && 'Đã giao hàng'}
              {order.status == 2 && 'Đã hủy'}
            </td>
          </tr>
        </tbody>
      </table>
      <div>
        <Link className="btn btn-secondary" to="/">Quay lại</Link> {" "}
        {order.status == 0 &&
        <>
          <button onClick={confirmOrder} className="btn btn-primary">Xác nhận đã giao</button> {" "}
          <button onClick={cancelOrder} className="btn btn-danger">Huỷ đơn hàng</button>
        </>
        }
      </div>
    </div>
  );
}