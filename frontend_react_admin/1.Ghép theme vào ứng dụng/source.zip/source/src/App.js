import './App.css';
import {
  Link,
  Routes,
  Route
} from "react-router-dom";

import OrderList from 'pages/OrderList';
import OrderDetail from 'pages/OrderDetail';
import Login from 'pages/Login';

function App() {
  const token = localStorage.getItem('token');
  if(!token) return <Login/>;
  
  return(
    <>
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary p-0">
        <div className="navbar-nav collapse navbar-collapse">
          <Link className="nav-item nav-link active" to="/">Quản lý đơn hàng</Link>
          <a className="nav-item nav-link" href="#/">Quản lý sản phẩm</a>
        </div>

        <ul className="navbar-nav ml-auto">
          <li className="nav-item no-arrow">
            <a className="nav-link dropdown-toggle p-0" data-bs-toggle="dropdown" href="void(0)">
              <img alt="" className="rounded-circle" style={{width:"60px"}}
                src="https://raw.githubusercontent.com/pytutorial/html_samples/master/css_bootstrap/user.svg" />
            </a>
            <div className="dropdown-menu dropdown-menu-end">
              <a className="dropdown-item" href="#/">
                Thông tin tài khoản
              </a>
              <div className="dropdown-divider"></div>
              <a className="dropdown-item" href="#/">
                Đăng xuất
              </a>
            </div>
          </li>
        </ul>
      </nav>
      
      <Routes>
        <Route path="/" element={<OrderList />}/>
        <Route path="/order-detail/:id" element={<OrderDetail />}/>
      </Routes>
    </>
  )
}

export default App;