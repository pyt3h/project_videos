import "./css/Login.css";

export default function Login() {
  return (
    <div className="bg-login">
      <div className="login-form">
        <h3>Đăng nhập</h3>

        <form method="POST" style={{marginTop: "30px"}}>
          <div className="mt-3">
            <label for="username" className="mb-1">Tên tài khoản</label>
            <input name="username" type="text" className="form-control"/>
          </div>
          <div className="mt-4">
            <label for="password" className="mb-1">Mật khẩu</label>
            <input name="password" type="password" className="form-control"/>
          </div>
          <div className="mt-3">
            <span id="error" style={{color: "red"}}></span>
          </div>
          <div style={{marginTop: "35px"}}>
            <button type="submit" className="btn btn-primary" style={{width:"100%"}}>Đăng nhập</button>
          </div>
        </form>
        <p className="text-center mt-4"><a href="#/">Đăng ký tài khoản</a></p>
      </div>
    </div>
  );
}