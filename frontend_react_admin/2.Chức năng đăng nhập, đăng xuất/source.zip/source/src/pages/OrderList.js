import { Link } from "react-router-dom";

export default function OrderList() {
  return (
    <div className="container mt-3">
      <form className="row">
        <div className="col-9">
          <input className="form-control" placeholder="Tìm kiếm theo tên/sđt khách hàng/tên sản phẩm" />
        </div>
        <div className="col-3">
          <button className="btn btn-primary">Tìm kiếm</button>
        </div>
      </form>
      <table className="table mt-3">
        <thead>
          <tr>
            <th style={{width:"25%"}}>Khách hàng</th>
            <th style={{width:"25%"}}>Sản phẩm</th>
            <th style={{width:"20%"}}>Ngày mua</th>
            <th style={{width:"20%"}}>Trạng thái</th>
            <th style={{width:"10%"}}></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Nguyễn Văn A (01231456)</td>
            <td>Acer 001 (Số lượng: 1)</td>
            <td>10:30:00 19/05/2022</td>
            <td>Đang chờ giao hàng</td>
            <td>
              <Link className="btn btn-sm btn-secondary" to="/order-detail/1">Xem</Link>
            </td>
          </tr>
        </tbody>
      </table>
      <nav aria-label="Page navigation example">
        <ul className="pagination">
          <li className="page-item"><a className="page-link" href="#/">&laquo;</a></li>
          <li className="page-item"><a className="page-link" href="#/">&lsaquo;</a></li>
          <li className="page-item"><a className="page-link" href="#/">&rsaquo;</a></li>
          <li className="page-item"><a className="page-link" href="#/">&raquo;</a></li>
        </ul>
        <span>Hiển thị 1-10 trên tổng số 25 đơn hàng</span>
      </nav>
    </div>
  );
}