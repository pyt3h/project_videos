import { useState } from "react";
import { BASE_URL } from "config";
import "./css/Login.css";

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const logIn = async function(e) {
    e.preventDefault();
    let data = {username: username, password: password};
    data = JSON.stringify(data);
    let options = {
      method: "POST",
      body: data,
      headers: {"Content-Type": "application/json"}
    };
    let url = BASE_URL + '/api/token';
    let resp = await fetch(url, options);
    if(resp.status != 200) {
      setError('Tên đăng nhập hoặc mật khẩu không đúng')
    }else {
      let result = await resp.json();
      localStorage.setItem('token', result.access);
      window.location.href = '/';
    }
  }

  return (
    <div className="bg-login">
      <div className="login-form">
        <h3>Đăng nhập</h3>

        <form onSubmit={logIn} method="POST" style={{marginTop: "30px"}}>
          <div className="mt-3">
            <label for="username" className="mb-1">Tên tài khoản</label>
            <input name="username" type="text" className="form-control"
              value={username} onChange={e => setUsername(e.target.value)}
             />
          </div>
          <div className="mt-4">
            <label for="password" className="mb-1">Mật khẩu</label>
            <input name="password" type="password" className="form-control" 
              value={password} onChange={e => setPassword(e.target.value)}
            />
          </div>
          <div className="mt-3">
            <span id="error" style={{color: "red"}}>{error}</span>
          </div>
          <div style={{marginTop: "35px"}}>
            <button type="submit" className="btn btn-primary" style={{width:"100%"}}>Đăng nhập</button>
          </div>
        </form>
        <p className="text-center mt-4"><a href="#/">Đăng ký tài khoản</a></p>
      </div>
    </div>
  );
}