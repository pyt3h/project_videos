import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { BASE_URL } from "config";
import "./css/OrderProduct.css";

export default function OrderProduct(){
  const {id} = useParams();
  const navigate = useNavigate();
  const [qty, setQty] = useState(1);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerAddress, setCustomerAddress] = useState("");
  const [product, setProduct] = useState({});

  useEffect(function(){
    let url = BASE_URL + '/api/get-product-by-id/' + id;
    fetch(url).then(resp => resp.json()).then(result => setProduct(result));
  }, []);

  const saveOrder = async function(e) {
    e.preventDefault();
    let data = {
      product_id: id,
      qty: parseInt(qty),
      customer_name: customerName,
      customer_phone: customerPhone,
      customer_address: customerAddress
    };
    data = JSON.stringify(data);
    //alert(data);
    let options = {
      method: 'POST',
      body: data,
      headers: {"Content-Type": "application/json"}
    };
    let url = BASE_URL + '/api/save-order';
    let resp = await fetch(url, options);
    if(resp.status != 200) {
      let result = await resp.json();
      alert(result.error);
    }else {
      navigate('/thank-you');
    }
  }

  return (
    <div className="container mt-5 mb-5">
      <form onSubmit={saveOrder} method="POST" novalidate>
        <h4>Đặt mua hàng trực tuyến</h4>
        <table className="table table-form">
          <tbody>
            <tr>
              <th colspan="2">
                <h5>Thông tin sản phẩm</h5>
              </th>
            </tr>
            <tr>
              <th>Tên sản phẩm:</th>
              <td>{product.name}</td>
            </tr>
            <tr>
              <th>Đơn giá:</th>
              <td>{product.price} ₫</td>
            </tr>
            <tr>
              <th>Số lượng:</th>
              <td>
                <div style={{width:"50px"}}>
                  <input className="form-control" type="number" value={qty} min="1"
                    onChange={e => setQty(e.target.value)}
                  />
                </div>
              </td>
            </tr>
            <tr>
              <th colspan="2">
                <h5>Thông tin người mua hàng</h5>
              </th>
            </tr>
            <tr>
              <th>Họ và tên:</th>
              <td>
                <input className="form-control" value={customerName} 
                  onChange={e => setCustomerName(e.target.value)}
                />
              </td>
            </tr>
            <tr>
              <th>Số điện thoại:</th>
              <td>
                <input className="form-control" value={customerPhone}
                  onChange={e=> setCustomerPhone(e.target.value)} 
                />
              </td>
            </tr>
            <tr>
              <th>Địa chỉ:</th>
              <td>
                <input className="form-control" value={customerAddress}
                  onChange={e => setCustomerAddress(e.target.value)}
                />
              </td>
            </tr>
          </tbody>
        </table>
        <button className="btn btn-primary">
          Đặt mua
        </button>
      </form>
    </div>
  );
}