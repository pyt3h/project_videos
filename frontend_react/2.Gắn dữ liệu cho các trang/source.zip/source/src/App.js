import './App.css';
import {
  Link,
  Routes,
  Route
} from "react-router-dom";

import Home from "./pages/Home";
import ProductDetail from "./pages/ProductDetail";
import OrderProduct from "./pages/OrderProduct";
import ThankYou from "./pages/ThankYou";

function App() {
  return(
    <>
      <div class="bg-primary">
        <div class="container">
          <nav class="navbar navbar-expand navbar-dark bg-primary p-0">
            <ul class="navbar-nav">
              <li class="nav-item">
                <Link class="nav-link active" to="/">Sản phẩm</Link>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#/">Liên hệ</a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
      
      <Routes>
        <Route path="/" element={<Home />}/>
        <Route path="/product-detail/:id" element={<ProductDetail />}/>
        <Route path="/order-product/:id" element={<OrderProduct />}/>
        <Route path="/thank-you" element={<ThankYou />}/>
      </Routes>
    </>
  )
}

export default App;