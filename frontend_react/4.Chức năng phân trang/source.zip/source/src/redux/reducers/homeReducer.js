export const Action = {
  SET_STATE: 'setState'
}

const initialState = {
  loading: false,
  total: 0,
  page: 1,
  productList: [],
  brandList: [],
  priceRangeList: [
    {minPrice: null, maxPrice: null, name: 'Tất cả'},
    {minPrice: 0, maxPrice: 10000000, name: 'Dưới 10 triệu'},
    {minPrice: 10000000, maxPrice: 20000000, name: 'Từ 10-20 triệu'},
    {minPrice: 20000000, maxPrice: null, name: 'Trên 20 triệu'},
  ],
  searchParams: {
    keyword: '',
    brandId: null,
    priceRangeIndex:0
  },
  lastSearchParams: {
    keyword: '',
    brandId: null,
    priceRangeIndex:0
  }
}

const reducer = (state=initialState, action) => {
  if(action.type === 'home/' + Action.SET_STATE) {
    return {...state, ...action.payload};
  }
  return state;
}

export default reducer;