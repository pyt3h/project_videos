import { configureStore } from '@reduxjs/toolkit'
import appReducer from "./reducers/appReducer";
import homeReducer from "./reducers/homeReducer";

const store = configureStore({
  reducer: {
    app: appReducer,
    home: homeReducer
  }
});

export default store;