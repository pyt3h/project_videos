import { useEffect } from "react";
import { useSliceStore, useSliceSelector } from "utils/reduxHelper";
import { Link } from "react-router-dom";
import { BASE_URL } from "config";
import "./css/Home.css";

function getProductList(store) {
  const {searchParams, priceRangeList} = store.getState();

  let url = BASE_URL + '/api/search-product?';
  if(searchParams.keyword) url += '&keyword=' + searchParams.keyword;
  if(searchParams.brandId) url += '&brand_id=' + searchParams.brandId;
  const {minPrice, maxPrice} = priceRangeList[searchParams.priceRangeIndex];
  if(minPrice) url += '&min_price=' + minPrice;
  if(maxPrice) url += '&max_price=' + maxPrice;

  //alert(url);

  fetch(url).then(resp => resp.json()).then(result => {
    //console.log(result);
    store.setState({
      productList: result.items,
      total: result.total
    })
  });
}

function getBrandList(store) {
  let url = BASE_URL + '/api/get-all-brand';
  //alert(url);
  fetch(url).then(resp => resp.json()).then(result => store.setState({brandList: result}));
}

export default function Home(){
  const store = useSliceStore('home');
  const [
    productList,
    brandList,
    priceRangeList,
    searchParams
  ] = useSliceSelector('home', ['productList', 'brandList', 'priceRangeList', 'searchParams']);

  useEffect(function(){
    getBrandList(store);
    getProductList(store);
  }, []);
  
  const setSearchParams = function(params) {
    const {searchParams} = store.getState();
    store.setState({
      searchParams: {...searchParams, ...params}
    })
  };

  const searchProduct = function(e) {
    e.preventDefault();
    getProductList(store);
  }

  return (
    <div className="container mt-5 mb-5">
      <div className="row">
        <div className="col-3 p-3 card">
          <form onSubmit={searchProduct}>
            <div className="product-search-info mt-3">
              <label for="name" className="mb-1"><b>Tên sản phẩm:</b></label>
              <input name="name" className="form-control" placeholder="Nhập tên sản phẩm để tìm" 
                value={searchParams.keyword} onChange={e => setSearchParams({keyword: e.target.value})}
              />
            </div>

            <div className="brand-search-info mt-3">
              <label for="brandId"><b>Hãng sản xuất:</b></label>
              <div className="mt-2">
                <input type="radio" name="brandId" checked={!searchParams.brandId} 
                  onClick={() => setSearchParams({brandId: null})}
                /> {"  "}
                <span>Tất cả</span>
              </div>
              {brandList.map(brand => 
                <div className="mt-1" key={brand.id}>
                  <input name="brandId" type="radio" checked={searchParams.brandId == brand.id} 
                    onClick={() => setSearchParams({brandId: brand.id})}
                  /> {"  "}
                  <span>{brand.name}</span>
                </div>
              )}
            </div>

            <div className="price-search-info mt-3">
              <label for="priceRange"><b>Mức giá:</b></label>
              {priceRangeList.map((priceRange, index) => 
                <div className="mt-2" key={index}>
                  <input type="radio" name="priceRange" checked={searchParams.priceRangeIndex == index} 
                    onClick={() => setSearchParams({priceRangeIndex: index})}
                  /> {"  "}
                  <span>{priceRange.name}</span>
                </div>
              )}
            </div>

            <button type="submit" className="btn btn-primary mt-4 mb-4">Tìm kiếm</button>
          </form>
        </div>
        <div className="col-9">
          <ul className="list-unstyled row">
            {productList.map(product =>
              <li className="list-item col-sm-4 mt-3" key={product.id}>
                <div className="item-container">
                  <Link to={"/product-detail/"+product.id} className="product-item">
                    <img src={BASE_URL+product.image} className="product-image" alt="" />
                    <div className="item-info">
                      <div>
                        <span className="product-name">{product.name}</span>
                      </div>
                      <div>
                        <span className="price-title">Giá bán :</span>
                        <span className="price">{product.price} ₫</span>
                      </div>
                    </div>
                  </Link>
                </div>
              </li>
            )}
            
          </ul>
          <nav aria-label="Page navigation example">
            <ul className="pagination">
              <li className="page-item"><a className="page-link" href="#/">&laquo;</a></li>
              <li className="page-item"><a className="page-link" href="#/">&lsaquo;</a></li>
              <li className="page-item"><a className="page-link" href="#/">&rsaquo;</a></li>
              <li className="page-item"><a className="page-link" href="#/">&raquo;</a></li>
            </ul>
            <span>Hiển thị 1-10 trên tổng số 25 sản phẩm</span>
          </nav>
        </div>
      </div>
    </div>
  )
}