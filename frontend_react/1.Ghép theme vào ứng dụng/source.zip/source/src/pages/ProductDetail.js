import { Link } from "react-router-dom";
import "./css/ProductDetail.css";

export default function ProductDetail(){
  return (
    <div className="container mt-5 mb-5">
      <div className="row">
        <div className="col-6">
          <img alt="" className="product-detail-image" src="images/ACER_0001.jpeg" />
        </div>
    
        <div className="col-6 mt-5">
          <div className="product-detail-title">Acer 001</div>
          <br />
          <table className="table">
            <tbody>
              <tr>
                <td>Hãng sản xuất:</td>
                <td>Acer</td>
              </tr>
              <tr>
                <td>Giá bán:</td>
                <td><b>6.500.000 ₫</b></td>
              </tr>
            </tbody>
          </table>
          <br />
          <Link className="btn btn-secondary" to="/">Quay lại</Link> {" "}
          <Link className="btn btn-primary" to="/order-product/1">Mua hàng</Link>
        </div>
      </div>
    </div> 
  );
}